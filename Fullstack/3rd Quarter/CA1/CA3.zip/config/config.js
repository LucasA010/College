const PORT = 3000;
const MAX_PLAYER_SIZE = 4;

export {
    PORT,
    MAX_PLAYER_SIZE
}